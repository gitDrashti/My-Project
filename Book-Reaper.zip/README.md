# BookReaper
A web application that provides the features of an online bookstore with some additional features.

To run the project:

1. Start MongoDb.
2. Run npm install from terminal.
3. Run 'node seed.js' from terminal.
4. Run 'npm start'
5. Sign up for a new account.
6. Login and continue.